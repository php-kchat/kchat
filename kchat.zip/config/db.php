<?php

 return array(
    "db_host" => "localhost",
    "db_user" => "root",
    "db_pass" => "mysql",
    "db_db" => "chat",
    "db_port" => "3306",
    "db_prefix" => ""
); 

?>