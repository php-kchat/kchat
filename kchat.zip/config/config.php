<?php

 return array(
    "path" => "E:\\Ampps\\www\\kchat",
    "url" => "http://localhost/kchat",
    "ds" => "\\",
    "secret" => "7H7WZSMfmOMYsTOFhiABk3O6do6r575dStUYtBwMZx4ZqWTxvDorgFdNnNJl32bg",
    "session" => "KChat_1ZGobGCK",
    "salt" => "bLhMoxjS9qz30AMuPPRIAhmcG2g0U7Ff",
    "key" => "E6RVK9lj",
    "version" => "1.0.0"
); 

?>