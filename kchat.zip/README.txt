http://www.geonames.org/manual.html
https://dev.maxmind.com/geoip/legacy/geolite/
https://dev.maxmind.com/geoip/geoip2/geolite2/