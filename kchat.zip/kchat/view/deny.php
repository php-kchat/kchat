You don't have direct permission to access
<script>alert('You don\'t have direct permission to access');</script>