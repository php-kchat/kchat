<div class="col-md-10 content">
	<div class="panel panel-default">
		<div class="panel-heading">
			Dashboard
		</div>
		<div class="panel-body" >
			
		</div>
	</div>
</div>