<div class="col-md-2 sidebar">
	<div class="row">
		<div class="absolute-wrapper">
		</div>
		<div class="side-menu">
			<nav class="navbar navbar-default" role="navigation">
				<div class="side-menu-container">
					<ul class="nav navbar-nav">
						<?php 
							sitebar($data,$data['sitebar']);
						?>
					</ul>
				</div>
			</nav>
		</div>
	</div>
</div>