<?php

/**
* KChat -
* Author Ganesh Kandu
* Contact kanduganesh@gmail.com 
*/

class deny{
	function index($data){
		$this->load->view('deny');
	}
}